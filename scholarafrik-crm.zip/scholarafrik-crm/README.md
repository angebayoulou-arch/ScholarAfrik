# ScholarAfrik CRM

Application de gestion des candidatures, bourses, clients, paiements et dépenses de ScholarAfrik.

- `apps/api` — Backend NestJS + Prisma + PostgreSQL (authentification JWT, rôles, tous les modules métier)
- `apps/web` — Frontend Next.js (interface CRM)

Un guide de déploiement complet (pas à pas, sans compte préalable requis) se trouve dans **DEPLOIEMENT.md**.

## Démarrage rapide en local

### 1. Backend

```bash
cd apps/api
cp .env.example .env
# renseigner DATABASE_URL et JWT_SECRET dans .env
npm install
npx prisma migrate dev --name init
npx prisma db seed
npm run start:dev
```

L'API démarre sur http://localhost:3001. Un compte administrateur est créé automatiquement :

- Email : `admin@scholarafrik.com`
- Mot de passe : `Admin@2026`

**Important : changez ce mot de passe dès la première connexion en production.**

### 2. Frontend

```bash
cd apps/web
cp .env.example .env.local
# renseigner NEXT_PUBLIC_API_URL (http://localhost:3001 en local)
npm install
npm run dev
```

Le frontend démarre sur http://localhost:3000.

## Rôles utilisateurs

| Rôle | Accès |
|---|---|
| `PRINCIPAL` | Total (tous les modules, finances, gestion des utilisateurs) |
| `CANDIDATURES` | Candidatures, clients/prospects, publications, calendrier, documents, relances |
| `COMPTABLE` | Paiements, dépenses, chiffre d'affaires, rapports financiers |
| `COMMUNITY` | Publications, calendrier éditorial, statistiques, prospects, messages |

## Structure des modules backend

`auth`, `users`, `clients`, `candidatures`, `scholarships` (calendrier des bourses), `documents`, `payments`, `expenses`, `reports`, `notifications`, `settings`.

Chaque module expose des routes REST protégées par JWT + garde de rôles (`@Roles(...)`).

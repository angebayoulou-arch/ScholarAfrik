import { IsArray, IsOptional, IsString } from 'class-validator';

export class UpdateSettingsDto {
  @IsOptional() @IsString() companyName?: string;
  @IsOptional() @IsString() logoUrl?: string;
  @IsOptional() @IsString() primaryColor?: string;
  @IsOptional() @IsArray() phones?: string[];
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() website?: string;
}

export class CreatePublicationDto {
  @IsString() date: string;
  @IsString() platform: string;
  @IsString() content: string;
  @IsOptional() @IsString() status?: string;
}

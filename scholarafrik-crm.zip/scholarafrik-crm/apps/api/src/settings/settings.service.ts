import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePublicationDto, UpdateSettingsDto } from './dto';

@Injectable()
export class SettingsService {
  constructor(private prisma: PrismaService) {}

  async get() {
    let settings = await this.prisma.settings.findUnique({ where: { id: 'default' } });
    if (!settings) {
      settings = await this.prisma.settings.create({ data: { id: 'default' } });
    }
    return settings;
  }

  update(dto: UpdateSettingsDto) {
    return this.prisma.settings.upsert({
      where: { id: 'default' },
      update: dto,
      create: { id: 'default', ...dto },
    });
  }

  findPublications() {
    return this.prisma.publication.findMany({ orderBy: { date: 'asc' } });
  }

  createPublication(dto: CreatePublicationDto) {
    return this.prisma.publication.create({ data: { ...dto, date: new Date(dto.date) } });
  }

  async removePublication(id: string) {
    await this.prisma.publication.delete({ where: { id } });
    return { success: true };
  }
}

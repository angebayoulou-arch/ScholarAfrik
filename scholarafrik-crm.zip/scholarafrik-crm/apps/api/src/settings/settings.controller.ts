import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { Role } from '@prisma/client';
import { SettingsService } from './settings.service';
import { CreatePublicationDto, UpdateSettingsDto } from './dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@UseGuards(JwtAuthGuard)
@Controller('settings')
export class SettingsController {
  constructor(private service: SettingsService) {}

  @Get() get() { return this.service.get(); }

  @UseGuards(RolesGuard)
  @Roles(Role.PRINCIPAL)
  @Patch()
  update(@Body() dto: UpdateSettingsDto) { return this.service.update(dto); }

  @Get('publications') findPublications() { return this.service.findPublications(); }

  @UseGuards(RolesGuard)
  @Roles(Role.PRINCIPAL, Role.CANDIDATURES, Role.COMMUNITY)
  @Post('publications')
  createPublication(@Body() dto: CreatePublicationDto) { return this.service.createPublication(dto); }

  @UseGuards(RolesGuard)
  @Roles(Role.PRINCIPAL, Role.COMMUNITY)
  @Delete('publications/:id')
  removePublication(@Param('id') id: string) { return this.service.removePublication(id); }
}

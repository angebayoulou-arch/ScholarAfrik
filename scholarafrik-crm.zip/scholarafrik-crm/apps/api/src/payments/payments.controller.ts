import { Body, Controller, Delete, Get, Param, Post, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { Role } from '@prisma/client';
import { PaymentsService } from './payments.service';
import { CreatePaymentDto } from './dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.PRINCIPAL, Role.COMPTABLE)
@Controller('payments')
export class PaymentsController {
  constructor(private service: PaymentsService) {}

  @Get() findAll() { return this.service.findAll(); }
  @Get('summary') summary() { return this.service.summary(); }
  @Post() create(@Body() dto: CreatePaymentDto) { return this.service.create(dto); }
  @Delete(':id') remove(@Param('id') id: string) { return this.service.remove(id); }

  @Get(':id/receipt')
  receipt(@Param('id') id: string, @Res() res: Response) {
    return this.service.generateReceipt(id, res);
  }
}

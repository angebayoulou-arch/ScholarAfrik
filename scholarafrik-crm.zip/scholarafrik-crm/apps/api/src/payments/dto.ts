import { IsEnum, IsInt, IsOptional, IsString, Min } from 'class-validator';
import { PaymentMode, PaymentType } from '@prisma/client';

export class CreatePaymentDto {
  @IsString() clientId: string;
  @IsInt() @Min(1) amount: number;
  @IsEnum(PaymentMode) mode: PaymentMode;
  @IsEnum(PaymentType) type: PaymentType;
  @IsOptional() @IsString() date?: string;
}

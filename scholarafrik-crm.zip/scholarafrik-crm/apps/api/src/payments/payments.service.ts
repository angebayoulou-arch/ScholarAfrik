import { Injectable, NotFoundException } from '@nestjs/common';
import PDFDocument from 'pdfkit';
import { Response } from 'express';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePaymentDto } from './dto';

@Injectable()
export class PaymentsService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.payment.findMany({
      include: { client: { select: { fullName: true } } },
      orderBy: { date: 'desc' },
    });
  }

  create(dto: CreatePaymentDto) {
    return this.prisma.payment.create({
      data: { ...dto, date: dto.date ? new Date(dto.date) : new Date() },
    });
  }

  async summary() {
    const payments = await this.prisma.payment.findMany();
    const total = payments.reduce((s, p) => s + p.amount, 0);
    return { total, count: payments.length };
  }

  async remove(id: string) {
    await this.prisma.payment.delete({ where: { id } });
    return { success: true };
  }

  async generateReceipt(id: string, res: Response) {
    const payment = await this.prisma.payment.findUnique({ where: { id }, include: { client: true } });
    if (!payment) throw new NotFoundException('Paiement introuvable.');

    const doc = new PDFDocument({ margin: 50 });
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="recu-${payment.id}.pdf"`,
    });
    doc.pipe(res);

    doc.fontSize(20).fillColor('#F97316').text('ScholarAfrik', { align: 'left' });
    doc.fontSize(10).fillColor('black').text('Votre succès, notre mission');
    doc.moveDown(2);
    doc.fontSize(16).text('REÇU DE PAIEMENT', { align: 'center' });
    doc.moveDown();

    doc.fontSize(11);
    doc.text(`Client : ${payment.client.fullName}`);
    doc.text(`Date : ${payment.date.toLocaleDateString('fr-FR')}`);
    doc.text(`Montant : ${payment.amount.toLocaleString('fr-FR')} FCFA`);
    doc.text(`Mode de paiement : ${payment.mode}`);
    doc.text(`Type : ${payment.type}`);
    doc.moveDown(2);
    doc.fontSize(9).fillColor('gray').text('scholarafrik@gmail.com — +226 58 07 72 92', { align: 'left' });

    doc.end();
  }
}

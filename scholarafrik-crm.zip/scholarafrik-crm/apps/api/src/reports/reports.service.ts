import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import { Response } from 'express';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  async overview() {
    const [clients, candidatures, payments, expenses] = await Promise.all([
      this.prisma.client.findMany(),
      this.prisma.candidature.findMany(),
      this.prisma.payment.findMany(),
      this.prisma.expense.findMany(),
    ]);

    const totalCA = payments.reduce((s, p) => s + p.amount, 0);
    const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
    const accepted = candidatures.filter((c) => c.stage === 'ACCEPTE').length;
    const refused = candidatures.filter((c) => c.stage === 'REFUSE').length;
    const tauxReussite = accepted + refused > 0 ? Math.round((accepted / (accepted + refused)) * 100) : 0;

    const byCountry: Record<string, number> = {};
    for (const c of clients) {
      const key = c.country || 'Non renseigné';
      byCountry[key] = (byCountry[key] || 0) + 1;
    }

    const byUniversity: Record<string, number> = {};
    for (const c of clients) {
      if (!c.university) continue;
      byUniversity[c.university] = (byUniversity[c.university] || 0) + 1;
    }

    return {
      chiffreAffaires: totalCA,
      depenses: totalExpenses,
      beneficeNet: totalCA - totalExpenses,
      nombreClients: clients.length,
      admissions: accepted,
      tauxReussite,
      candidaturesParStatut: this.groupBy(candidatures, 'stage'),
      clientsParPays: byCountry,
      universitesLesPlusDemandees: byUniversity,
    };
  }

  async exportExcel(): Promise<Buffer> {
    const overview = await this.overview();
    const payments = await this.prisma.payment.findMany({ include: { client: true } });

    const workbook = new ExcelJS.Workbook();
    const summary = workbook.addWorksheet('Résumé');
    summary.columns = [{ header: 'Indicateur', key: 'k', width: 30 }, { header: 'Valeur', key: 'v', width: 20 }];
    summary.addRows([
      { k: "Chiffre d'affaires (FCFA)", v: overview.chiffreAffaires },
      { k: 'Dépenses (FCFA)', v: overview.depenses },
      { k: 'Bénéfice net (FCFA)', v: overview.beneficeNet },
      { k: 'Nombre de clients', v: overview.nombreClients },
      { k: 'Admissions obtenues', v: overview.admissions },
      { k: 'Taux de réussite (%)', v: overview.tauxReussite },
    ]);

    const paySheet = workbook.addWorksheet('Paiements');
    paySheet.columns = [
      { header: 'Date', key: 'date', width: 15 },
      { header: 'Client', key: 'client', width: 25 },
      { header: 'Montant (FCFA)', key: 'amount', width: 18 },
      { header: 'Mode', key: 'mode', width: 15 },
      { header: 'Type', key: 'type', width: 15 },
    ];
    payments.forEach((p) =>
      paySheet.addRow({
        date: p.date.toISOString().slice(0, 10),
        client: p.client.fullName,
        amount: p.amount,
        mode: p.mode,
        type: p.type,
      }),
    );

    const buffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(buffer);
  }

  async exportPdf(res: Response) {
    const overview = await this.overview();
    const doc = new PDFDocument({ margin: 40 });
    doc.pipe(res);

    doc.fontSize(18).fillColor('#F97316').text('ScholarAfrik CRM', { align: 'left' });
    doc.fontSize(12).fillColor('black').text('Rapport de performance', { align: 'left' });
    doc.moveDown();

    const rows: [string, string][] = [
      ["Chiffre d'affaires", `${overview.chiffreAffaires.toLocaleString('fr-FR')} FCFA`],
      ['Dépenses', `${overview.depenses.toLocaleString('fr-FR')} FCFA`],
      ['Bénéfice net', `${overview.beneficeNet.toLocaleString('fr-FR')} FCFA`],
      ['Nombre de clients', String(overview.nombreClients)],
      ['Admissions obtenues', String(overview.admissions)],
      ['Taux de réussite', `${overview.tauxReussite}%`],
    ];

    rows.forEach(([label, value]) => {
      doc.fontSize(11).text(`${label} : ${value}`);
    });

    doc.end();
  }

  private groupBy(items: any[], key: string) {
    return items.reduce((acc, item) => {
      const k = item[key];
      acc[k] = (acc[k] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  }
}

import { Controller, Get, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { Role } from '@prisma/client';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.PRINCIPAL, Role.COMPTABLE)
@Controller('reports')
export class ReportsController {
  constructor(private service: ReportsService) {}

  @Get('overview')
  overview() {
    return this.service.overview();
  }

  @Get('export/excel')
  async exportExcel(@Res() res: Response) {
    const buffer = await this.service.exportExcel();
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="rapport-scholarafrik.xlsx"',
    });
    res.send(buffer);
  }

  @Get('export/pdf')
  async exportPdf(@Res() res: Response) {
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'attachment; filename="rapport-scholarafrik.pdf"',
    });
    await this.service.exportPdf(res);
  }
}

import { IsInt, IsOptional, IsString, Min } from 'class-validator';

export class CreateExpenseDto {
  @IsString() categoryId: string;
  @IsInt() @Min(1) amount: number;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() date?: string;
}

export class CreateCategoryDto {
  @IsString() name: string;
}

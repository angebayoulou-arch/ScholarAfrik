import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCategoryDto, CreateExpenseDto } from './dto';

@Injectable()
export class ExpensesService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.expense.findMany({
      include: { category: true },
      orderBy: { date: 'desc' },
    });
  }

  create(dto: CreateExpenseDto) {
    return this.prisma.expense.create({
      data: { ...dto, date: dto.date ? new Date(dto.date) : new Date() },
    });
  }

  async summary() {
    const expenses = await this.prisma.expense.findMany();
    const total = expenses.reduce((s, e) => s + e.amount, 0);
    return { total, count: expenses.length };
  }

  findCategories() {
    return this.prisma.expenseCategory.findMany();
  }

  createCategory(dto: CreateCategoryDto) {
    return this.prisma.expenseCategory.create({ data: dto });
  }

  async remove(id: string) {
    await this.prisma.expense.delete({ where: { id } });
    return { success: true };
  }
}

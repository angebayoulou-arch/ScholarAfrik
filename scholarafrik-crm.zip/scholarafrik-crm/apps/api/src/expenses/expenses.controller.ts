import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { Role } from '@prisma/client';
import { ExpensesService } from './expenses.service';
import { CreateCategoryDto, CreateExpenseDto } from './dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.PRINCIPAL, Role.COMPTABLE)
@Controller('expenses')
export class ExpensesController {
  constructor(private service: ExpensesService) {}

  @Get() findAll() { return this.service.findAll(); }
  @Get('summary') summary() { return this.service.summary(); }
  @Post() create(@Body() dto: CreateExpenseDto) { return this.service.create(dto); }
  @Delete(':id') remove(@Param('id') id: string) { return this.service.remove(id); }

  @Get('categories') findCategories() { return this.service.findCategories(); }
  @Post('categories') createCategory(@Body() dto: CreateCategoryDto) { return this.service.createCategory(dto); }
}

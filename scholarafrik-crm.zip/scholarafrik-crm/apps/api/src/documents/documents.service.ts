import { Injectable, Inject, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateDocumentDto } from './dto';
import streamifier from 'streamifier';

@Injectable()
export class DocumentsService {
  constructor(private prisma: PrismaService, @Inject('CLOUDINARY') private cloudinary: any) {}

  findByClient(clientId: string) {
    return this.prisma.document.findMany({ where: { clientId }, orderBy: { uploadedAt: 'desc' } });
  }

  async upload(file: Express.Multer.File, dto: CreateDocumentDto) {
    const uploadResult: any = await new Promise((resolve, reject) => {
      const stream = this.cloudinary.uploader.upload_stream(
        { folder: `scholarafrik/${dto.clientId}`, resource_type: 'auto' },
        (error: any, result: any) => (error ? reject(error) : resolve(result)),
      );
      streamifier.createReadStream(file.buffer).pipe(stream);
    });

    return this.prisma.document.create({
      data: {
        clientId: dto.clientId,
        type: dto.type,
        fileUrl: uploadResult.secure_url,
        fileName: file.originalname,
      },
    });
  }

  async remove(id: string) {
    const doc = await this.prisma.document.findUnique({ where: { id } });
    if (!doc) throw new NotFoundException('Document introuvable.');
    await this.prisma.document.delete({ where: { id } });
    return { success: true };
  }
}

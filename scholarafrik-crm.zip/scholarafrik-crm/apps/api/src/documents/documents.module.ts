import { Module } from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { DocumentsController } from './documents.controller';
import { CloudinaryProvider } from './cloudinary.provider';

@Module({
  controllers: [DocumentsController],
  providers: [DocumentsService, CloudinaryProvider],
})
export class DocumentsModule {}

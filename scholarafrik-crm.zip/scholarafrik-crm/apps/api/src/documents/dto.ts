import { IsEnum, IsString } from 'class-validator';
import { DocumentType } from '@prisma/client';

export class CreateDocumentDto {
  @IsString() clientId: string;
  @IsEnum(DocumentType) type: DocumentType;
}

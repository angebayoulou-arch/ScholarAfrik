import { IsOptional, IsString } from 'class-validator';

export class CreateScholarshipDto {
  @IsString() name: string;
  @IsOptional() @IsString() country?: string;
  @IsOptional() @IsString() level?: string;
  @IsOptional() @IsString() opening?: string;
  @IsOptional() @IsString() closing?: string;
  @IsOptional() @IsString() status?: string;
}
export class UpdateScholarshipDto extends CreateScholarshipDto {}

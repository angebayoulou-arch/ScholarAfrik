import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateScholarshipDto, UpdateScholarshipDto } from './dto';

@Injectable()
export class ScholarshipsService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.scholarship.findMany({ orderBy: { closing: 'asc' } });
  }

  async findOne(id: string) {
    const s = await this.prisma.scholarship.findUnique({ where: { id } });
    if (!s) throw new NotFoundException('Bourse introuvable.');
    return s;
  }

  create(dto: CreateScholarshipDto) {
    return this.prisma.scholarship.create({
      data: {
        ...dto,
        opening: dto.opening ? new Date(dto.opening) : null,
        closing: dto.closing ? new Date(dto.closing) : null,
      },
    });
  }

  async update(id: string, dto: UpdateScholarshipDto) {
    await this.findOne(id);
    return this.prisma.scholarship.update({
      where: { id },
      data: {
        ...dto,
        opening: dto.opening ? new Date(dto.opening) : undefined,
        closing: dto.closing ? new Date(dto.closing) : undefined,
      },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.scholarship.delete({ where: { id } });
    return { success: true };
  }
}

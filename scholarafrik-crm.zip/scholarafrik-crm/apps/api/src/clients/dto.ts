import { IsOptional, IsString } from 'class-validator';

export class CreateClientDto {
  @IsString()
  fullName: string;

  @IsOptional() @IsString() phone?: string;
  @IsOptional() @IsString() whatsapp?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() country?: string;
  @IsOptional() @IsString() university?: string;
  @IsOptional() @IsString() program?: string;
  @IsOptional() @IsString() scholarshipType?: string;
  @IsOptional() @IsString() status?: string;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsString() responsibleId?: string;
}

export class UpdateClientDto extends CreateClientDto {}

import { Injectable } from '@nestjs/common';
import { NotificationType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class NotificationsService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.notification.findMany({ orderBy: { createdAt: 'desc' }, take: 50 });
  }

  create(type: NotificationType, message: string) {
    return this.prisma.notification.create({ data: { type, message } });
  }

  async markAsRead(id: string) {
    await this.prisma.notification.update({ where: { id }, data: { isRead: true } });
    return { success: true };
  }

  /** Génère les notifications automatiques : échéances proches, paiements en retard, etc. */
  async runAutomaticChecks() {
    const soon = new Date();
    soon.setDate(soon.getDate() + 3);

    const urgentCandidatures = await this.prisma.candidature.findMany({
      where: { deadline: { lte: soon, gte: new Date() }, stage: { notIn: ['DEPOSE', 'ACCEPTE', 'REFUSE'] } },
      include: { client: true },
    });

    for (const c of urgentCandidatures) {
      await this.create(
        'CANDIDATURE_A_DEPOSER',
        `Candidature à déposer bientôt : ${c.client.fullName} (échéance ${c.deadline?.toLocaleDateString('fr-FR')})`,
      );
    }

    return { generated: urgentCandidatures.length };
  }
}

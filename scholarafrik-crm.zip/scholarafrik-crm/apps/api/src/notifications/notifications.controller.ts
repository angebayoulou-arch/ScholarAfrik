import { Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('notifications')
export class NotificationsController {
  constructor(private service: NotificationsService) {}

  @Get() findAll() { return this.service.findAll(); }
  @Patch(':id/read') markAsRead(@Param('id') id: string) { return this.service.markAsRead(id); }
  @Post('run-checks') runChecks() { return this.service.runAutomaticChecks(); }
}

import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CandidaturesService } from './candidatures.service';
import { AddCommentDto, CreateCandidatureDto, UpdateCandidatureDto } from './dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.PRINCIPAL, Role.CANDIDATURES)
@Controller('candidatures')
export class CandidaturesController {
  constructor(private service: CandidaturesService) {}

  @Get()
  findAll(@Query('stage') stage?: string) {
    return this.service.findAll(stage);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateCandidatureDto) {
    return this.service.create(dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateCandidatureDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }

  @Post(':id/comments')
  addComment(@Param('id') id: string, @CurrentUser() user: any, @Body() dto: AddCommentDto) {
    return this.service.addComment(id, user.id, dto);
  }
}

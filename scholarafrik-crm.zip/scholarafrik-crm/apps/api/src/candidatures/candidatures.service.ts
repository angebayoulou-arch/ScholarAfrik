import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AddCommentDto, CreateCandidatureDto, UpdateCandidatureDto } from './dto';

@Injectable()
export class CandidaturesService {
  constructor(private prisma: PrismaService) {}

  findAll(stage?: string) {
    return this.prisma.candidature.findMany({
      where: stage ? { stage: stage as any } : undefined,
      include: { client: { select: { id: true, fullName: true } }, comments: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const c = await this.prisma.candidature.findUnique({
      where: { id },
      include: { client: true, comments: { include: { author: { select: { fullName: true } } } } },
    });
    if (!c) throw new NotFoundException('Candidature introuvable.');
    return c;
  }

  create(dto: CreateCandidatureDto) {
    return this.prisma.candidature.create({
      data: { ...dto, deadline: dto.deadline ? new Date(dto.deadline) : null },
    });
  }

  async update(id: string, dto: UpdateCandidatureDto) {
    await this.findOne(id);
    return this.prisma.candidature.update({
      where: { id },
      data: { ...dto, deadline: dto.deadline ? new Date(dto.deadline) : undefined },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.candidature.delete({ where: { id } });
    return { success: true };
  }

  async addComment(id: string, userId: string, dto: AddCommentDto) {
    await this.findOne(id);
    return this.prisma.candidatureComment.create({
      data: { candidatureId: id, authorId: userId, content: dto.content },
    });
  }
}

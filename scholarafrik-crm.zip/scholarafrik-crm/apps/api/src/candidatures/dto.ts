import { IsEnum, IsInt, IsOptional, IsString, Max, Min } from 'class-validator';
import { CandidatureStage } from '@prisma/client';

export class CreateCandidatureDto {
  @IsString()
  clientId: string;

  @IsOptional() @IsString() country?: string;
  @IsOptional() @IsString() program?: string;
  @IsOptional() @IsString() deadline?: string; // ISO date

  @IsOptional() @IsEnum(CandidatureStage) stage?: CandidatureStage;

  @IsOptional() @IsInt() @Min(1) @Max(3) priority?: number;
}

export class UpdateCandidatureDto {
  @IsOptional() @IsString() country?: string;
  @IsOptional() @IsString() program?: string;
  @IsOptional() @IsString() deadline?: string;
  @IsOptional() @IsEnum(CandidatureStage) stage?: CandidatureStage;
  @IsOptional() @IsInt() @Min(1) @Max(3) priority?: number;
}

export class AddCommentDto {
  @IsString()
  content: string;
}

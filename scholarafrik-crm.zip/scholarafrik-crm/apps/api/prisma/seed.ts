import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('Admin@2026', 10);

  await prisma.user.upsert({
    where: { email: 'admin@scholarafrik.com' },
    update: {},
    create: {
      email: 'admin@scholarafrik.com',
      passwordHash,
      fullName: 'Administrateur ScholarAfrik',
      role: Role.PRINCIPAL,
    },
  });

  await prisma.settings.upsert({
    where: { id: 'default' },
    update: {},
    create: {
      id: 'default',
      companyName: 'ScholarAfrik',
      primaryColor: '#F97316',
      phones: ['+22658077292', '+22665223581', '+22655149859'],
      email: 'scholarafrik@gmail.com',
      website: 'https://crm.scholarafrik.com',
    },
  });

  const categories = ['Publicité', 'Frais bancaires', 'Bureautique', 'Déplacement', 'Autre'];
  for (const name of categories) {
    await prisma.expenseCategory.upsert({
      where: { name },
      update: {},
      create: { name },
    });
  }

  console.log('Seed terminé. Compte admin : admin@scholarafrik.com / Admin@2026');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

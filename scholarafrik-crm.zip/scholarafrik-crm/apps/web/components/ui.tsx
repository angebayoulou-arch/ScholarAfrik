'use client';
import { X } from 'lucide-react';

export function StatCard({ label, value, color, icon: Icon }: { label: string; value: string | number; color: string; icon?: any }) {
  return (
    <div className="rounded-xl p-4 text-white shadow-sm flex flex-col justify-between min-h-[92px]" style={{ backgroundColor: color }}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold tracking-wide uppercase opacity-90">{label}</span>
        {Icon && <Icon size={16} className="opacity-80" />}
      </div>
      <div className="text-2xl font-bold leading-tight mt-1">{value}</div>
    </div>
  );
}

export function Panel({ title, right, children, className = '' }: { title?: string; right?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-white rounded-xl border border-slate-200 shadow-sm ${className}`}>
      {title && (
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
          <h3 className="text-xs font-bold tracking-wide text-slate-700 uppercase">{title}</h3>
          {right}
        </div>
      )}
      <div className="p-4">{children}</div>
    </div>
  );
}

export function Badge({ children, color }: { children: React.ReactNode; color: string }) {
  return (
    <span className="inline-block px-2 py-0.5 rounded-md text-[11px] font-semibold" style={{ backgroundColor: color + '22', color }}>
      {children}
    </span>
  );
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className={`bg-white rounded-xl shadow-xl w-full ${wide ? 'max-w-2xl' : 'max-w-md'} max-h-[90vh] overflow-y-auto`}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h3 className="font-bold text-slate-800">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block mb-3">
      <span className="block text-xs font-semibold text-slate-500 mb-1">{label}</span>
      {children}
    </label>
  );
}

export const inputCls = 'w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400';

export const COLORS = {
  blue: '#2563EB', green: '#16A34A', orange: '#F97316', purple: '#7C3AED',
  teal: '#0D9488', pink: '#DB2777', navy: '#0F172A', amber: '#D97706',
};

export const fmt = (n: number) => new Intl.NumberFormat('fr-FR').format(n || 0) + ' FCFA';

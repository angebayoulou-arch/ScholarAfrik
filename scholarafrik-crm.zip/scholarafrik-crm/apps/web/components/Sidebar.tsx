'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { logout } from '@/lib/api';
import {
  LayoutDashboard, Users, FileText, Calendar, FolderOpen, Wallet,
  Receipt, BarChart3, Settings, LogOut, Megaphone, MessageSquare,
} from 'lucide-react';

const MODULES: Record<string, { label: string; icon: any; href: string }> = {
  dashboard: { label: 'Tableau de bord', icon: LayoutDashboard, href: '/dashboard' },
  clients: { label: 'Clients', icon: Users, href: '/clients' },
  candidatures: { label: 'Candidatures', icon: FileText, href: '/candidatures' },
  calendrier: { label: 'Calendrier des bourses', icon: Calendar, href: '/calendrier' },
  documents: { label: 'Documents', icon: FolderOpen, href: '/documents' },
  paiements: { label: 'Paiements', icon: Wallet, href: '/paiements' },
  depenses: { label: 'Dépenses', icon: Receipt, href: '/depenses' },
  rapports: { label: 'Rapports & Statistiques', icon: BarChart3, href: '/rapports' },
  parametres: { label: 'Paramètres', icon: Settings, href: '/parametres' },
  publications: { label: 'Publications', icon: Megaphone, href: '/publications' },
  messages: { label: 'Messages & Relances', icon: MessageSquare, href: '/messages' },
};

const ROLE_MODULES: Record<string, string[]> = {
  PRINCIPAL: ['dashboard', 'clients', 'candidatures', 'calendrier', 'documents', 'paiements', 'depenses', 'rapports', 'parametres'],
  CANDIDATURES: ['dashboard', 'clients', 'candidatures', 'publications', 'calendrier', 'documents', 'messages'],
  COMPTABLE: ['dashboard', 'paiements', 'depenses', 'rapports'],
  COMMUNITY: ['dashboard', 'publications', 'clients', 'messages'],
};

const ROLE_LABELS: Record<string, string> = {
  PRINCIPAL: 'Gestionnaire Principal',
  CANDIDATURES: 'Gestionnaire des candidatures',
  COMPTABLE: 'Comptable',
  COMMUNITY: 'Community Manager',
};

export default function Sidebar({ user }: { user: { email: string; role: string; fullName: string } }) {
  const pathname = usePathname();
  const modules = ROLE_MODULES[user.role] || ['dashboard'];

  return (
    <aside className="w-64 shrink-0 text-white flex flex-col bg-navy min-h-screen">
      <div className="px-5 py-5 border-b border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-xl font-extrabold text-orange">S</span>
          <span className="text-xl font-extrabold">A</span>
          <span className="font-bold text-sm ml-1">ScholarAfrik</span>
        </div>
        <p className="text-[10px] text-slate-400 mt-0.5">Votre succès, notre mission</p>
      </div>

      <div className="px-5 py-4 flex items-center gap-3 border-b border-white/10">
        <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm bg-orange">
          {user.fullName?.[0]?.toUpperCase() || 'U'}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold truncate">{user.fullName}</p>
          <p className="text-[11px] text-slate-400 truncate">{ROLE_LABELS[user.role]}</p>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {modules.map((key) => {
          const m = MODULES[key];
          const Icon = m.icon;
          const isActive = pathname === m.href;
          return (
            <Link
              key={key}
              href={m.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                isActive ? 'bg-orange text-white' : 'text-slate-300 hover:bg-white/5'
              }`}
            >
              <Icon size={16} />
              {m.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-3 py-4 border-t border-white/10">
        <button onClick={logout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:bg-white/5">
          <LogOut size={16} /> Déconnexion
        </button>
        <div className="text-[10px] text-slate-500 px-3 mt-3 leading-relaxed">
          +226 58 07 72 92 / +226 65 22 35 81<br />
          scholarafrik@gmail.com
        </div>
      </div>
    </aside>
  );
}

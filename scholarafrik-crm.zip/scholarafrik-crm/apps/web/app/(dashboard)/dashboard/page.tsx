'use client';
import { useEffect, useState } from 'react';
import { apiFetch, getCurrentUser } from '@/lib/api';
import { StatCard, Panel, fmt, COLORS } from '@/components/ui';
import { Users, Briefcase, AlertTriangle, FileText, CheckCircle2, Wallet, Clock, TrendingUp, Receipt, DollarSign, Megaphone } from 'lucide-react';

export default function DashboardPage() {
  const user = getCurrentUser();
  const [overview, setOverview] = useState<any>(null);
  const [clients, setClients] = useState<any[]>([]);
  const [candidatures, setCandidatures] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const role = user?.role;
        const calls: Promise<any>[] = [];
        if (role === 'PRINCIPAL' || role === 'CANDIDATURES' || role === 'COMMUNITY') calls.push(apiFetch('/clients').then(setClients));
        if (role === 'PRINCIPAL' || role === 'CANDIDATURES') calls.push(apiFetch('/candidatures').then(setCandidatures));
        if (role === 'PRINCIPAL' || role === 'COMPTABLE') {
          calls.push(apiFetch('/payments').then(setPayments));
          calls.push(apiFetch('/expenses').then(setExpenses));
          calls.push(apiFetch('/reports/overview').then(setOverview));
        }
        await Promise.all(calls);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <p className="text-slate-400 text-sm">Chargement…</p>;

  const totalCA = payments.reduce((s, p) => s + p.amount, 0);
  const totalDep = expenses.reduce((s, e) => s + e.amount, 0);
  const accepted = candidatures.filter((c) => c.stage === 'ACCEPTE').length;
  const enCours = clients.filter((c) => c.status === 'En cours').length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-extrabold text-slate-800">Tableau de bord</h1>
        <p className="text-xs text-slate-400">Bienvenue, {user?.fullName}</p>
      </div>

      {(user?.role === 'PRINCIPAL') && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
            <StatCard label="Total clients" value={clients.length} color={COLORS.blue} icon={Users} />
            <StatCard label="Dossiers en cours" value={enCours} color={COLORS.green} icon={Briefcase} />
            <StatCard label="Dossiers urgents" value={candidatures.filter((c) => c.priority === 1).length} color={COLORS.orange} icon={AlertTriangle} />
            <StatCard label="Candidatures" value={candidatures.length} color={COLORS.purple} icon={FileText} />
            <StatCard label="Admissions" value={accepted} color={COLORS.teal} icon={CheckCircle2} />
            <StatCard label="Chiffre d'affaires" value={fmt(totalCA)} color={COLORS.navy} icon={TrendingUp} />
            <StatCard label="Dépenses" value={fmt(totalDep)} color={COLORS.pink} icon={Wallet} />
          </div>
          <Panel title="Résumé financier">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div><p className="text-slate-500">Bénéfice net</p><p className="text-lg font-bold text-orange">{fmt(totalCA - totalDep)}</p></div>
              <div><p className="text-slate-500">Taux de réussite</p><p className="text-lg font-bold text-slate-700">{overview?.tauxReussite ?? 0}%</p></div>
              <div><p className="text-slate-500">Nombre de clients</p><p className="text-lg font-bold text-slate-700">{clients.length}</p></div>
            </div>
          </Panel>
        </>
      )}

      {(user?.role === 'CANDIDATURES') && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard label="Candidatures en cours" value={candidatures.length} color={COLORS.blue} icon={FileText} />
            <StatCard label="À déposer" value={candidatures.filter((c) => c.stage === 'PRET_A_DEPOSER').length} color={COLORS.green} icon={Clock} />
            <StatCard label="Déposées" value={candidatures.filter((c) => c.stage === 'DEPOSE').length} color={COLORS.orange} icon={CheckCircle2} />
            <StatCard label="Admissions" value={accepted} color={COLORS.teal} icon={CheckCircle2} />
          </div>
          <Panel title="Mes candidatures récentes">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Client</th><th>Programme</th><th>Statut</th></tr></thead>
              <tbody>
                {candidatures.slice(0, 8).map((c: any) => (
                  <tr key={c.id} className="border-b border-slate-50">
                    <td className="py-2 font-medium text-slate-700">{c.client?.fullName}</td>
                    <td className="text-slate-500">{c.program}</td>
                    <td className="text-slate-500">{c.stage}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
        </>
      )}

      {(user?.role === 'COMPTABLE') && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard label="Chiffre d'affaires" value={fmt(totalCA)} color={COLORS.navy} icon={TrendingUp} />
          <StatCard label="Dépenses" value={fmt(totalDep)} color={COLORS.pink} icon={Receipt} />
          <StatCard label="Bénéfice net" value={fmt(totalCA - totalDep)} color={COLORS.green} icon={DollarSign} />
          <StatCard label="Paiements" value={payments.length} color={COLORS.blue} icon={Wallet} />
        </div>
      )}

      {(user?.role === 'COMMUNITY') && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard label="Prospects" value={clients.length} color={COLORS.blue} icon={Users} />
          <StatCard label="Publications" value="—" color={COLORS.purple} icon={Megaphone} />
        </div>
      )}
    </div>
  );
}

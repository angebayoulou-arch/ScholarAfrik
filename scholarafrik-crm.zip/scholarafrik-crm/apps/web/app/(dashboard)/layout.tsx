'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '@/components/Sidebar';
import { getCurrentUser } from '@/lib/api';
import { Bell, Search } from 'lucide-react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const u = getCurrentUser();
    if (!u) {
      router.replace('/login');
    } else {
      setUser(u);
    }
    setChecked(true);
  }, [router]);

  if (!checked) return null;
  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <Sidebar user={user} />
      <main className="flex-1 min-w-0 flex flex-col">
        <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400 bg-slate-100 rounded-lg px-3 py-1.5 w-80">
            <Search size={15} />
            <input placeholder="Rechercher…" className="bg-transparent outline-none text-sm w-full text-slate-700" />
          </div>
          <button className="relative text-slate-500 hover:text-slate-800">
            <Bell size={19} />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto p-6">{children}</div>
      </main>
    </div>
  );
}

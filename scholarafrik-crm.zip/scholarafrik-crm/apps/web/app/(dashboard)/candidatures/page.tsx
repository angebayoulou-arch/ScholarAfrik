'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Modal, Field, inputCls } from '@/components/ui';
import { Plus, Clock } from 'lucide-react';

const STAGES = ['PREPARATION', 'DOCUMENTS_MANQUANTS', 'PRET_A_DEPOSER', 'DEPOSE', 'EN_EVALUATION', 'ACCEPTE', 'REFUSE'];
const STAGE_LABELS: Record<string, string> = {
  PREPARATION: 'Préparation', DOCUMENTS_MANQUANTS: 'Documents manquants', PRET_A_DEPOSER: 'Prêt à déposer',
  DEPOSE: 'Déposé', EN_EVALUATION: 'En évaluation', ACCEPTE: 'Accepté', REFUSE: 'Refusé',
};
const STAGE_COLOR: Record<string, string> = {
  PREPARATION: '#7C3AED', DOCUMENTS_MANQUANTS: '#D97706', PRET_A_DEPOSER: '#0D9488',
  DEPOSE: '#2563EB', EN_EVALUATION: '#64748B', ACCEPTE: '#16A34A', REFUSE: '#DC2626',
};

export default function CandidaturesPage() {
  const [candidatures, setCandidatures] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ clientId: '', country: '', program: '', deadline: '', stage: 'PREPARATION' });

  async function load() {
    const [ca, cl] = await Promise.all([apiFetch('/candidatures'), apiFetch('/clients')]);
    setCandidatures(ca);
    setClients(cl);
  }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.clientId) return;
    await apiFetch('/candidatures', { method: 'POST', body: JSON.stringify(form) });
    setForm({ clientId: '', country: '', program: '', deadline: '', stage: 'PREPARATION' });
    setShowAdd(false);
    load();
  }

  async function moveStage(id: string, dir: number) {
    const c = candidatures.find((x) => x.id === id);
    const idx = STAGES.indexOf(c.stage);
    const newStage = STAGES[Math.min(Math.max(idx + dir, 0), STAGES.length - 1)];
    await apiFetch(`/candidatures/${id}`, { method: 'PATCH', body: JSON.stringify({ stage: newStage }) });
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-slate-800">Candidatures</h1>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Nouvelle candidature
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-2">
        {STAGES.map((stage) => {
          const items = candidatures.filter((c) => c.stage === stage);
          return (
            <div key={stage} className="min-w-[240px] w-60 shrink-0">
              <div className="flex items-center justify-between mb-2 px-1">
                <span className="text-xs font-bold uppercase" style={{ color: STAGE_COLOR[stage] }}>{STAGE_LABELS[stage]}</span>
                <span className="text-xs text-slate-400">{items.length}</span>
              </div>
              <div className="space-y-2">
                {items.map((c) => (
                  <div key={c.id} className="bg-white border border-slate-200 rounded-lg p-3 shadow-sm">
                    <p className="text-sm font-semibold text-slate-700">{c.client?.fullName}</p>
                    <p className="text-xs text-slate-400">{c.program} · {c.country}</p>
                    {c.deadline && <p className="text-xs text-slate-400 mt-1 flex items-center gap-1"><Clock size={11} /> {new Date(c.deadline).toLocaleDateString('fr-FR')}</p>}
                    <div className="flex justify-between mt-2">
                      <button onClick={() => moveStage(c.id, -1)} className="text-[11px] text-slate-400 hover:text-slate-700">← Reculer</button>
                      <button onClick={() => moveStage(c.id, 1)} className="text-[11px] font-semibold text-orange">Avancer →</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {showAdd && (
        <Modal title="Nouvelle candidature" onClose={() => setShowAdd(false)}>
          <Field label="Client">
            <select className={inputCls} value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value })}>
              <option value="">— Sélectionner —</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.fullName}</option>)}
            </select>
          </Field>
          <Field label="Pays"><input className={inputCls} value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></Field>
          <Field label="Programme"><input className={inputCls} value={form.program} onChange={(e) => setForm({ ...form, program: e.target.value })} /></Field>
          <Field label="Date limite"><input type="date" className={inputCls} value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} /></Field>
          <button onClick={add} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Créer</button>
        </Modal>
      )}
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Badge, COLORS } from '@/components/ui';

export default function MessagesPage() {
  const [notifications, setNotifications] = useState<any[]>([]);
  useEffect(() => { apiFetch('/notifications').then(setNotifications); }, []);

  return (
    <div className="space-y-4">
      <h1 className="text-lg font-extrabold text-slate-800">Messages & Relances</h1>
      <Panel title="Notifications récentes">
        <ul className="divide-y divide-slate-100">
          {notifications.map((n) => (
            <li key={n.id} className="py-3 flex items-center justify-between">
              <p className="text-sm text-slate-700">{n.message}</p>
              <Badge color={n.isRead ? COLORS.blue : COLORS.amber}>{n.isRead ? 'Lu' : 'Nouveau'}</Badge>
            </li>
          ))}
          {notifications.length === 0 && <p className="text-sm text-slate-400 py-4">Aucune notification pour le moment.</p>}
        </ul>
      </Panel>
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge } from '@/components/ui';
import { Plus } from 'lucide-react';

export default function CalendrierPage() {
  const [scholarships, setScholarships] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', country: '', level: '', opening: '', closing: '', status: 'Ouvert' });

  async function load() { setScholarships(await apiFetch('/scholarships')); }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.name) return;
    await apiFetch('/scholarships', { method: 'POST', body: JSON.stringify(form) });
    setForm({ name: '', country: '', level: '', opening: '', closing: '', status: 'Ouvert' });
    setShowAdd(false);
    load();
  }

  function daysLeft(closing: string) {
    if (!closing) return null;
    return Math.ceil((new Date(closing).getTime() - Date.now()) / 86400000);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-slate-800">Calendrier des bourses</h1>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Ajouter une bourse
        </button>
      </div>
      <Panel>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Bourse</th><th>Pays</th><th>Clôture</th><th>Jours restants</th><th>Statut</th></tr></thead>
          <tbody>
            {scholarships.map((s) => {
              const dl = daysLeft(s.closing);
              return (
                <tr key={s.id} className="border-b border-slate-50">
                  <td className="py-2.5 font-medium text-slate-700">{s.name}</td>
                  <td className="text-slate-500">{s.country}</td>
                  <td className="text-slate-500">{s.closing ? new Date(s.closing).toLocaleDateString('fr-FR') : '—'}</td>
                  <td className={dl !== null && dl <= 15 && dl >= 0 ? 'text-red-500 font-semibold' : 'text-slate-500'}>{dl !== null ? (dl >= 0 ? `${dl} jours` : 'Clôturé') : '—'}</td>
                  <td><Badge color={s.status === 'Ouvert' ? '#16A34A' : '#D97706'}>{s.status}</Badge></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Panel>
      {showAdd && (
        <Modal title="Ajouter une bourse" onClose={() => setShowAdd(false)}>
          <Field label="Nom"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Pays"><input className={inputCls} value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></Field>
          <Field label="Niveau"><input className={inputCls} value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })} /></Field>
          <Field label="Ouverture"><input type="date" className={inputCls} value={form.opening} onChange={(e) => setForm({ ...form, opening: e.target.value })} /></Field>
          <Field label="Clôture"><input type="date" className={inputCls} value={form.closing} onChange={(e) => setForm({ ...form, closing: e.target.value })} /></Field>
          <button onClick={add} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Ajouter</button>
        </Modal>
      )}
    </div>
  );
}

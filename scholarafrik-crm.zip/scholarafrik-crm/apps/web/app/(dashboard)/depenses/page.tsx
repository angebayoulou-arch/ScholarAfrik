'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge, StatCard, COLORS, fmt } from '@/components/ui';
import { Plus, Receipt } from 'lucide-react';

export default function DepensesPage() {
  const [expenses, setExpenses] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ categoryId: '', amount: '', description: '' });

  async function load() {
    const [e, c] = await Promise.all([apiFetch('/expenses'), apiFetch('/expenses/categories')]);
    setExpenses(e); setCategories(c);
  }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.categoryId || !form.amount) return;
    await apiFetch('/expenses', { method: 'POST', body: JSON.stringify({ ...form, amount: Number(form.amount) }) });
    setForm({ categoryId: '', amount: '', description: '' });
    setShowAdd(false);
    load();
  }

  const total = expenses.reduce((s, e) => s + e.amount, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <StatCard label="Total dépenses" value={fmt(total)} color={COLORS.pink} icon={Receipt} />
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Nouvelle dépense
        </button>
      </div>
      <Panel title="Historique des dépenses">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Date</th><th>Catégorie</th><th>Description</th><th>Montant</th></tr></thead>
          <tbody>
            {expenses.map((e) => (
              <tr key={e.id} className="border-b border-slate-50">
                <td className="py-2.5 text-slate-500">{new Date(e.date).toLocaleDateString('fr-FR')}</td>
                <td><Badge color={COLORS.pink}>{e.category?.name}</Badge></td>
                <td className="text-slate-500">{e.description}</td>
                <td className="text-red-500 font-semibold">{fmt(e.amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      {showAdd && (
        <Modal title="Nouvelle dépense" onClose={() => setShowAdd(false)}>
          <Field label="Catégorie">
            <select className={inputCls} value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
              <option value="">— Sélectionner —</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Montant (FCFA)"><input type="number" className={inputCls} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
          <Field label="Description"><input className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <button onClick={add} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Enregistrer</button>
        </Modal>
      )}
    </div>
  );
}

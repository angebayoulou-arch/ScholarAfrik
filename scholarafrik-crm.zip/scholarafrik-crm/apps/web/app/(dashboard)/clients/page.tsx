'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge, COLORS } from '@/components/ui';
import { Plus, Search, Phone, Mail } from 'lucide-react';

const emptyForm = { fullName: '', country: '', university: '', program: '', scholarshipType: 'À la carte', phone: '', whatsapp: '', email: '', status: 'Préparation' };

export default function ClientsPage() {
  const [clients, setClients] = useState<any[]>([]);
  const [q, setQ] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const data = await apiFetch(`/clients${q ? `?search=${encodeURIComponent(q)}` : ''}`);
      setClients(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function addClient() {
    if (!form.fullName) return;
    await apiFetch('/clients', { method: 'POST', body: JSON.stringify(form) });
    setForm(emptyForm);
    setShowAdd(false);
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-lg font-extrabold text-slate-800">Clients</h1>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2 w-64">
            <Search size={15} className="text-slate-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} placeholder="Rechercher…" className="outline-none text-sm w-full" />
          </div>
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
            <Plus size={16} /> Nouveau client
          </button>
        </div>
      </div>

      <Panel>
        {loading ? <p className="text-slate-400 text-sm">Chargement…</p> : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100">
                <th className="py-2">Client</th><th>Pays</th><th>Programme</th><th>Contact</th><th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50">
                  <td className="py-2.5 font-medium text-slate-700">{c.fullName}</td>
                  <td className="text-slate-500">{c.country}</td>
                  <td className="text-slate-500">{c.program}</td>
                  <td className="text-slate-500">
                    <div className="flex items-center gap-1 text-xs"><Phone size={11} />{c.phone}</div>
                    <div className="flex items-center gap-1 text-xs"><Mail size={11} />{c.email}</div>
                  </td>
                  <td><Badge color={COLORS.blue}>{c.status}</Badge></td>
                </tr>
              ))}
              {clients.length === 0 && <tr><td colSpan={5} className="text-center text-slate-400 py-8">Aucun client.</td></tr>}
            </tbody>
          </table>
        )}
      </Panel>

      {showAdd && (
        <Modal title="Nouveau client" onClose={() => setShowAdd(false)} wide>
          <div className="grid grid-cols-2 gap-x-4">
            <Field label="Nom complet"><input className={inputCls} value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></Field>
            <Field label="Pays"><input className={inputCls} value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></Field>
            <Field label="Université"><input className={inputCls} value={form.university} onChange={(e) => setForm({ ...form, university: e.target.value })} /></Field>
            <Field label="Programme"><input className={inputCls} value={form.program} onChange={(e) => setForm({ ...form, program: e.target.value })} /></Field>
            <Field label="Type de bourse">
              <select className={inputCls} value={form.scholarshipType} onChange={(e) => setForm({ ...form, scholarshipType: e.target.value })}>
                <option>À la carte</option><option>Pack Complet</option>
              </select>
            </Field>
            <Field label="Statut">
              <select className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option>Préparation</option><option>En attente documents</option><option>Prêt à déposer</option><option>En cours</option>
              </select>
            </Field>
            <Field label="Téléphone"><input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="WhatsApp"><input className={inputCls} value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} /></Field>
            <Field label="Email"><input className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          </div>
          <button onClick={addClient} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Enregistrer le client</button>
        </Modal>
      )}
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge, StatCard, COLORS, fmt } from '@/components/ui';
import { Plus, Download, Wallet } from 'lucide-react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

export default function PaiementsPage() {
  const [payments, setPayments] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ clientId: '', amount: '', mode: 'ESPECES', type: 'ACOMPTE' });

  async function load() {
    const [p, c] = await Promise.all([apiFetch('/payments'), apiFetch('/clients')]);
    setPayments(p); setClients(c);
  }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.clientId || !form.amount) return;
    await apiFetch('/payments', { method: 'POST', body: JSON.stringify({ ...form, amount: Number(form.amount) }) });
    setForm({ clientId: '', amount: '', mode: 'ESPECES', type: 'ACOMPTE' });
    setShowAdd(false);
    load();
  }

  async function downloadReceipt(id: string) {
    const token = localStorage.getItem('sa_token');
    const res = await fetch(`${API_URL}/api/payments/${id}/receipt`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  }

  const total = payments.reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <StatCard label="Total encaissé" value={fmt(total)} color={COLORS.green} icon={Wallet} />
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Enregistrer un paiement
        </button>
      </div>
      <Panel title="Historique des paiements">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Date</th><th>Client</th><th>Montant</th><th>Mode</th><th>Type</th><th></th></tr></thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-b border-slate-50">
                <td className="py-2.5 text-slate-500">{new Date(p.date).toLocaleDateString('fr-FR')}</td>
                <td className="font-medium text-slate-700">{p.client?.fullName}</td>
                <td className="text-green-600 font-semibold">{fmt(p.amount)}</td>
                <td className="text-slate-500">{p.mode}</td>
                <td><Badge color={p.type === 'COMPLET' ? COLORS.green : COLORS.amber}>{p.type}</Badge></td>
                <td className="text-right">
                  <button onClick={() => downloadReceipt(p.id)} className="text-xs text-slate-400 hover:text-orange flex items-center gap-1 justify-end ml-auto"><Download size={12} /> Reçu</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      {showAdd && (
        <Modal title="Enregistrer un paiement" onClose={() => setShowAdd(false)}>
          <Field label="Client">
            <select className={inputCls} value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value })}>
              <option value="">— Sélectionner —</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.fullName}</option>)}
            </select>
          </Field>
          <Field label="Montant (FCFA)"><input type="number" className={inputCls} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
          <Field label="Mode">
            <select className={inputCls} value={form.mode} onChange={(e) => setForm({ ...form, mode: e.target.value })}>
              <option value="ESPECES">Espèces</option><option value="ORANGE_MONEY">Orange Money</option>
              <option value="MOOV_MONEY">Moov Money</option><option value="VIREMENT">Virement</option>
            </select>
          </Field>
          <Field label="Type">
            <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="ACOMPTE">Acompte</option><option value="SOLDE">Solde</option><option value="COMPLET">Complet</option>
            </select>
          </Field>
          <button onClick={add} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Enregistrer</button>
        </Modal>
      )}
    </div>
  );
}

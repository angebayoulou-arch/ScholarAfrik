'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, fmt } from '@/components/ui';
import { Download } from 'lucide-react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

export default function RapportsPage() {
  const [overview, setOverview] = useState<any>(null);

  useEffect(() => { apiFetch('/reports/overview').then(setOverview); }, []);

  async function downloadFile(path: string, filename: string) {
    const token = localStorage.getItem('sa_token');
    const res = await fetch(`${API_URL}/api${path}`, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
  }

  if (!overview) return <p className="text-slate-400 text-sm">Chargement…</p>;

  const cards = [
    { label: "Chiffre d'affaires", value: fmt(overview.chiffreAffaires) },
    { label: 'Dépenses', value: fmt(overview.depenses) },
    { label: 'Bénéfice net', value: fmt(overview.beneficeNet) },
    { label: 'Nombre de clients', value: overview.nombreClients },
    { label: 'Admissions', value: overview.admissions },
    { label: 'Taux de réussite', value: `${overview.tauxReussite}%` },
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-lg font-extrabold text-slate-800">Rapports & Statistiques</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {cards.map((c) => (
          <Panel key={c.label}>
            <p className="text-xs text-slate-500">{c.label}</p>
            <p className="text-xl font-bold text-slate-800 mt-1">{c.value}</p>
          </Panel>
        ))}
      </div>
      <Panel title="Export">
        <div className="flex gap-3">
          <button onClick={() => downloadFile('/reports/export/pdf', 'rapport-scholarafrik.pdf')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold border border-slate-200 text-slate-600 hover:border-orange hover:text-orange">
            <Download size={15} /> Exporter en PDF
          </button>
          <button onClick={() => downloadFile('/reports/export/excel', 'rapport-scholarafrik.xlsx')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold border border-slate-200 text-slate-600 hover:border-orange hover:text-orange">
            <Download size={15} /> Exporter en Excel
          </button>
        </div>
      </Panel>
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge, COLORS } from '@/components/ui';
import { Phone, Mail, Globe2, Plus } from 'lucide-react';

const ROLE_LABELS: Record<string, string> = {
  PRINCIPAL: 'Gestionnaire Principal', CANDIDATURES: 'Gestionnaire des candidatures',
  COMPTABLE: 'Comptable', COMMUNITY: 'Community Manager',
};

export default function ParametresPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ email: '', fullName: '', password: '', role: 'CANDIDATURES' });

  async function load() {
    const [u, s] = await Promise.all([apiFetch('/users').catch(() => []), apiFetch('/settings')]);
    setUsers(u); setSettings(s);
  }
  useEffect(() => { load(); }, []);

  async function addUser() {
    if (!form.email || !form.password) return;
    await apiFetch('/users', { method: 'POST', body: JSON.stringify(form) });
    setForm({ email: '', fullName: '', password: '', role: 'CANDIDATURES' });
    setShowAdd(false);
    load();
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-slate-800">Paramètres</h1>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Nouvel utilisateur
        </button>
      </div>

      <Panel title="Utilisateurs & rôles">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Utilisateur</th><th>Email</th><th>Rôle</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-slate-50">
                <td className="py-2.5 font-medium text-slate-700">{u.fullName}</td>
                <td className="text-slate-500">{u.email}</td>
                <td><Badge color={COLORS.blue}>{ROLE_LABELS[u.role]}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>

      {settings && (
        <Panel title="Informations ScholarAfrik">
          <div className="space-y-2 text-sm text-slate-600">
            {(settings.phones || []).map((p: string) => (
              <p key={p} className="flex items-center gap-2"><Phone size={14} /> {p}</p>
            ))}
            <p className="flex items-center gap-2"><Mail size={14} /> {settings.email}</p>
            <p className="flex items-center gap-2"><Globe2 size={14} /> {settings.website}</p>
          </div>
        </Panel>
      )}

      {showAdd && (
        <Modal title="Nouvel utilisateur" onClose={() => setShowAdd(false)}>
          <Field label="Nom complet"><input className={inputCls} value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></Field>
          <Field label="Email"><input className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Mot de passe"><input type="password" className={inputCls} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
          <Field label="Rôle">
            <select className={inputCls} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              <option value="PRINCIPAL">Gestionnaire Principal</option>
              <option value="CANDIDATURES">Gestionnaire des candidatures</option>
              <option value="COMPTABLE">Comptable</option>
              <option value="COMMUNITY">Community Manager</option>
            </select>
          </Field>
          <button onClick={addUser} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Créer le compte</button>
        </Modal>
      )}
    </div>
  );
}

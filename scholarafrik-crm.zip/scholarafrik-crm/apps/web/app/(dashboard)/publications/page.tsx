'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Modal, Field, inputCls, Badge, COLORS } from '@/components/ui';
import { Plus } from 'lucide-react';

export default function PublicationsPage() {
  const [publications, setPublications] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ date: '', platform: 'Facebook', content: '' });

  async function load() { setPublications(await apiFetch('/settings/publications')); }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.content || !form.date) return;
    await apiFetch('/settings/publications', { method: 'POST', body: JSON.stringify(form) });
    setForm({ date: '', platform: 'Facebook', content: '' });
    setShowAdd(false);
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-slate-800">Calendrier éditorial</h1>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-semibold bg-orange">
          <Plus size={16} /> Programmer une publication
        </button>
      </div>
      <Panel>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b border-slate-100"><th className="py-2">Date</th><th>Plateforme</th><th>Contenu</th><th>Statut</th></tr></thead>
          <tbody>
            {publications.map((p) => (
              <tr key={p.id} className="border-b border-slate-50">
                <td className="py-2.5 text-slate-500">{new Date(p.date).toLocaleDateString('fr-FR')}</td>
                <td className="text-slate-500">{p.platform}</td>
                <td className="font-medium text-slate-700">{p.content}</td>
                <td><Badge color={COLORS.purple}>{p.status}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      {showAdd && (
        <Modal title="Programmer une publication" onClose={() => setShowAdd(false)}>
          <Field label="Date"><input type="date" className={inputCls} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          <Field label="Plateforme">
            <select className={inputCls} value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}>
              <option>Facebook</option><option>Instagram</option><option>TikTok</option><option>LinkedIn</option>
            </select>
          </Field>
          <Field label="Contenu"><textarea className={inputCls} rows={3} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></Field>
          <button onClick={add} className="w-full py-2.5 rounded-lg text-white font-semibold mt-2 bg-orange">Programmer</button>
        </Modal>
      )}
    </div>
  );
}

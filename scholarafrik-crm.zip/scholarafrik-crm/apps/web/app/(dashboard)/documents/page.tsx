'use client';
import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Panel, Badge } from '@/components/ui';
import { Upload, CheckCircle2 } from 'lucide-react';

const DOC_TYPES = [
  { key: 'PASSEPORT', label: 'Passeport' }, { key: 'DIPLOME', label: 'Diplôme' },
  { key: 'RELEVES', label: 'Relevés' }, { key: 'CV', label: 'CV' },
  { key: 'MOTIVATION', label: 'Lettre de motivation' }, { key: 'RECOMMANDATION', label: 'Recommandation' },
];

export default function DocumentsPage() {
  const [clients, setClients] = useState<any[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [docs, setDocs] = useState<any[]>([]);

  useEffect(() => { apiFetch('/clients').then((c) => { setClients(c); if (c[0]) setSelected(c[0].id); }); }, []);
  useEffect(() => { if (selected) apiFetch(`/documents/client/${selected}`).then(setDocs); }, [selected]);

  async function upload(type: string, file: File) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('clientId', selected);
    formData.append('type', type);
    await apiFetch('/documents/upload', { method: 'POST', body: formData });
    apiFetch(`/documents/client/${selected}`).then(setDocs);
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
      <Panel title="Clients" className="md:col-span-1">
        <ul className="space-y-1">
          {clients.map((c) => (
            <li key={c.id}>
              <button onClick={() => setSelected(c.id)} className={`w-full text-left px-3 py-2 rounded-lg text-sm ${selected === c.id ? 'bg-orange text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
                {c.fullName}
              </button>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel title="Documents du client sélectionné" className="md:col-span-3">
        <div className="grid sm:grid-cols-2 gap-3">
          {DOC_TYPES.map((t) => {
            const existing = docs.find((d) => d.type === t.key);
            return (
              <div key={t.key} className="border border-slate-200 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-700">{t.label}</p>
                  <p className="text-xs text-slate-400">{existing ? existing.fileName : 'Aucun fichier'}</p>
                </div>
                {existing ? (
                  <a href={existing.fileUrl} target="_blank" className="flex items-center gap-1 text-green-600 text-xs font-semibold"><CheckCircle2 size={14} /> Voir</a>
                ) : (
                  <label className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg text-white bg-orange cursor-pointer">
                    <Upload size={12} /> Téléverser
                    <input type="file" className="hidden" onChange={(e) => e.target.files && upload(t.key, e.target.files[0])} />
                  </label>
                )}
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}

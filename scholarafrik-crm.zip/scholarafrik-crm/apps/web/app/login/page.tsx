'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { login } from '@/lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@scholarafrik.com');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Identifiants incorrects.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0B1220] to-[#1a2440] p-4">
      <form onSubmit={handleSubmit} className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
        <div className="flex flex-col items-center mb-6">
          <div className="flex items-center gap-1 text-2xl font-extrabold">
            <span className="text-orange">S</span>
            <span className="text-slate-900">A</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900 mt-2">ScholarAfrik CRM</h1>
          <p className="text-sm text-slate-500 mt-1">Votre succès, notre mission</p>
        </div>

        <label className="block mb-3">
          <span className="block text-xs font-semibold text-slate-500 mb-1">Email</span>
          <input
            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            required
          />
        </label>
        <label className="block mb-3">
          <span className="block text-xs font-semibold text-slate-500 mb-1">Mot de passe</span>
          <input
            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            required
          />
        </label>

        {error && <p className="text-sm text-red-500 mb-3">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 rounded-lg text-white font-semibold bg-orange disabled:opacity-60"
        >
          {loading ? 'Connexion…' : 'Se connecter'}
        </button>
        <div className="text-center mt-3">
          <a href="#" className="text-xs text-slate-500 hover:text-orange">Mot de passe oublié</a>
        </div>
      </form>
    </div>
  );
}

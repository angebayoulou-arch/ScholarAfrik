/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        orange: { DEFAULT: '#F97316' },
        navy: { DEFAULT: '#0B1220' },
      },
    },
  },
  plugins: [],
};

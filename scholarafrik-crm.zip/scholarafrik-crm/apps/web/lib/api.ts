const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

function getToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('sa_token');
}

export async function apiFetch(path: string, options: RequestInit = {}) {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.body && !(options.body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers as Record<string, string>),
  };

  const res = await fetch(`${API_URL}/api${path}`, { ...options, headers });

  if (res.status === 401) {
    localStorage.removeItem('sa_token');
    localStorage.removeItem('sa_user');
    if (typeof window !== 'undefined') window.location.href = '/login';
    throw new Error('Session expirée');
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: 'Erreur inconnue' }));
    throw new Error(err.message || 'Erreur API');
  }

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) return res.json();
  return res;
}

export async function login(email: string, password: string) {
  const res = await fetch(`${API_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: 'Identifiants incorrects' }));
    throw new Error(err.message);
  }
  const data = await res.json();
  localStorage.setItem('sa_token', data.accessToken);
  localStorage.setItem('sa_user', JSON.stringify(data.user));
  return data.user;
}

export function logout() {
  localStorage.removeItem('sa_token');
  localStorage.removeItem('sa_user');
  window.location.href = '/login';
}

export function getCurrentUser() {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem('sa_user');
  return raw ? JSON.parse(raw) : null;
}

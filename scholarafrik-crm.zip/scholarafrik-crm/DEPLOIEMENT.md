# Guide de déploiement — ScholarAfrik CRM

Ce guide part du principe que vous n'avez **aucun compte** créé chez les fournisseurs. Suivez les étapes dans l'ordre. Comptez environ 45 à 60 minutes la première fois.

---

## Étape 0 — Mettre le code sur GitHub

1. Créez un compte sur https://github.com si vous n'en avez pas.
2. Créez un nouveau dépôt (bouton **New repository**), par exemple `scholarafrik-crm`. Laissez-le vide (sans README).
3. Sur votre ordinateur, dans le dossier `scholarafrik-crm` fourni :
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/VOTRE-COMPTE/scholarafrik-crm.git
   git push -u origin main
   ```

Railway et Vercel se connectent directement à GitHub pour déployer automatiquement à chaque `git push`.

---

## Étape 1 — Base de données PostgreSQL + Backend (Railway)

1. Créez un compte sur https://railway.app (connexion possible avec GitHub).
2. Cliquez **New Project** → **Provision PostgreSQL**. Railway crée une base de données et génère automatiquement une variable `DATABASE_URL`.
3. Dans le même projet, cliquez **New** → **GitHub Repo**, sélectionnez votre dépôt `scholarafrik-crm`.
4. Railway va détecter plusieurs dossiers : configurez le service pour qu'il pointe sur `apps/api` :
   - Dans les **Settings** du service, champ **Root Directory** : `apps/api`
   - **Build Command** : `npm install && npm run build`
   - **Start Command** : `npx prisma migrate deploy && npm run start:prod`
5. Dans l'onglet **Variables** du service backend, ajoutez :
   - `DATABASE_URL` → copiez la valeur depuis le service PostgreSQL (bouton "Reference variable" si proposé, sinon copiez-collez la valeur affichée dans le service PostgreSQL)
   - `JWT_SECRET` → une chaîne aléatoire longue (générez-en une sur https://generate-secret.vercel.app/32 par exemple)
   - `JWT_EXPIRES_IN` → `7d`
   - `FRONTEND_URL` → laissez `http://localhost:3000` pour l'instant, vous le mettrez à jour à l'étape 3
   - (optionnel, pour l'upload de documents) `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` — voir Étape 2
6. Cliquez **Deploy**. Une fois le déploiement terminé, Railway vous donne une URL publique du type `https://scholarafrik-api-production.up.railway.app`. **Notez-la**, vous en aurez besoin pour le frontend.
7. Le compte administrateur par défaut est créé automatiquement au premier déploiement (via `prisma migrate deploy` + seed). Si le seed ne s'exécute pas automatiquement, lancez-le manuellement depuis l'onglet **Shell** de Railway :
   ```bash
   npm run seed
   ```

**Compte admin créé automatiquement :**
- Email : `admin@scholarafrik.com`
- Mot de passe : `Admin@2026`

*(Changez ce mot de passe dès votre première connexion, via Paramètres → votre compte, une fois le frontend en ligne.)*

---

## Étape 2 — Stockage des documents (Cloudinary) — optionnel mais recommandé

1. Créez un compte gratuit sur https://cloudinary.com.
2. Sur le tableau de bord, vous trouverez directement **Cloud name**, **API Key**, **API Secret**.
3. Reportez ces 3 valeurs dans les variables Railway du backend (`CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`), puis redéployez le service (Railway le fait automatiquement en général).

Sans cette étape, tout le CRM fonctionne normalement — seul le module Documents (upload de fichiers) ne sera pas opérationnel.

---

## Étape 3 — Frontend (Vercel)

1. Créez un compte sur https://vercel.com (connexion avec GitHub).
2. Cliquez **Add New** → **Project**, sélectionnez votre dépôt `scholarafrik-crm`.
3. Dans la configuration du projet :
   - **Root Directory** : `apps/web`
   - **Framework Preset** : Next.js (détecté automatiquement)
4. Dans **Environment Variables**, ajoutez :
   - `NEXT_PUBLIC_API_URL` → l'URL Railway notée à l'étape 1 (ex. `https://scholarafrik-api-production.up.railway.app`)
5. Cliquez **Deploy**. Après quelques minutes, Vercel vous donne une URL du type `https://scholarafrik-crm.vercel.app`.
6. Retournez sur Railway, mettez à jour la variable `FRONTEND_URL` du backend avec cette URL Vercel (pour que le CORS autorise le frontend à appeler l'API), puis redéployez.

Votre CRM est maintenant en ligne et accessible depuis n'importe quel appareil.

---

## Étape 4 — Domaine personnalisé crm.scholarafrik.com

Cette étape suppose que le nom de domaine `scholarafrik.com` est déjà déposé chez un registrar (ex. Namecheap, OVH, Google Domains). Si ce n'est pas le cas, achetez-le d'abord chez l'un de ces fournisseurs.

1. Dans Vercel, ouvrez votre projet → **Settings** → **Domains** → ajoutez `crm.scholarafrik.com`.
2. Vercel affiche un enregistrement DNS à créer (type **CNAME**, pointant vers `cname.vercel-dns.com`).
3. Connectez-vous à l'interface de gestion DNS de votre registrar (là où vous avez acheté `scholarafrik.com`) et ajoutez cet enregistrement CNAME pour le sous-domaine `crm`.
4. Attendez la propagation DNS (de quelques minutes à quelques heures). Vercel active automatiquement le certificat HTTPS une fois le DNS validé.

---

## Récapitulatif des URLs et identifiants

| Élément | Valeur |
|---|---|
| Frontend | `https://crm.scholarafrik.com` (ou l'URL Vercel en attendant) |
| Backend / API | URL Railway (ex. `https://scholarafrik-api-production.up.railway.app`) |
| Admin par défaut | `admin@scholarafrik.com` / `Admin@2026` |

## Maintenance courante

- **Mettre à jour le code** : `git push` sur `main` redéploie automatiquement Railway et Vercel.
- **Ajouter un utilisateur** : une fois connecté en tant que Gestionnaire Principal, allez dans Paramètres → Nouvel utilisateur (aucun accès à la base de données requis).
- **Voir les logs en cas d'erreur** : onglet **Deployments** puis **Logs** sur Railway (backend) et Vercel (frontend).
- **Sauvegardes de la base de données** : Railway propose des sauvegardes automatiques sur les plans payants ; sur le plan gratuit, exportez régulièrement via `pg_dump` depuis l'onglet Database → Connect.
